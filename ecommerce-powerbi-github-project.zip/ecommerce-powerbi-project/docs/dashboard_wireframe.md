# One-page dashboard wireframe

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│ E-COMMERCE DELIVERY & SHIPPING ANALYTICS — 2026                            │
├─────────────────┬──────────────────┬──────────────────┬─────────────────────┤
│ Total Orders    │ Total Revenue    │ Late Delivery %  │ Avg Delivery Days   │
├─────────────────┴───────┬──────────┴────────┬─────────┴─────────────────────┤
│ 1. Orders by Method     │ 2. Late vs On Time│ 3. Monthly Order Trend        │
├─────────────────────────┼───────────────────┼───────────────────────────────┤
│ 4. Avg Cost by Carrier  │ 5. Weather & Late │ 6. Orders by Country          │
├─────────────────────────┴───────────────────┼───────────────────────────────┤
│ 7. Distance vs Delivery Time                │ Slicers: date/country/method  │
│                                             │ and carrier                   │
└─────────────────────────────────────────────┴───────────────────────────────┘
```

For an uncluttered Power BI report, expand chart 7 to full width and put slicers in a collapsible filter pane if needed.
