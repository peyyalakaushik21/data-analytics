# Build Guide — Seven-Chart Power BI Dashboard

## 1. Import and clean

Power BI Desktop → Get Data → Excel workbook → `data/ecommerce_delivery_shipping_2026.xlsx` → select `E-commerce_Delivery_Shipping_Da` → Transform Data. Rename query **Shipping**. Promote first row as headers if necessary. Check:

- Date: `order_date`.
- Decimal: `product_weight_kg`, `order_value_usd`, `distance_km`, `shipping_cost_usd`, `warehouse_processing_hours`.
- Whole number: `promised_delivery_days`, `actual_delivery_days`, `delivery_delay_days`, `customer_rating`, `delivery_attempts`.
- Text: all IDs, categories, country, city, statuses, Yes/No fields.
- Inspect missing values, duplicates in `order_id`, date range, and inconsistent labels. Do not silently delete records; document any corrections.

Close & Apply. In Model view, set `customer_country` data category to **Country/Region**. Set USD measures' display format to currency and percentages to 1 decimal place. Create the DAX measures in `dax/measures.dax` individually.

## 2. Seven visuals

| Visual | Fields | Formatting / interpretation |
|---|---|---|
| 1. Orders by Shipping Method | Clustered column: X `shipping_method`, Y `[Total Orders]` | Sort descending; turn on data labels. |
| 2. Delivery Timeliness | Donut: Legend `late_delivery`, Values `[Total Orders]` | Show category and %; subtitle: *Source late-delivery flag, all statuses*. |
| 3. Monthly Order Trend | Line: X `order_date` (Month + Year), Y `[Total Orders]` | Use continuous month-year axis, not month name alone. |
| 4. Carrier Shipping Cost | Clustered bar: Y `carrier`, X `[Avg Shipping Cost (USD)]` | Sort descending; currency formatting; compare descriptive averages, not causal carrier efficiency. |
| 5. Weather vs Delivery Timeliness | 100% stacked column: X `weather_condition`, Legend `late_delivery`, Y `[Total Orders]` | Displays share late/on time within each weather category; turn on % labels if available. |
| 6. Orders by Country | Filled map or Azure Maps: Location `customer_country`, Color/Size `[Total Orders]` | Set country geographic category; enable tooltips with orders and late %. If mapping visuals are disabled, use a country bar chart as a fallback and document substitution. |
| 7. Distance vs Delivery Time | Scatter: X `distance_km`, Y `actual_delivery_days`, Details `order_id`; tooltip `carrier`, `shipping_method` | Set X/Y aggregation to *Don't summarize* where available; with 50k rows use filters or sampling for performance. |

## 3. KPI cards and slicers

Top row cards: `[Total Orders]`, `[Total Revenue (USD)]`, `[Late Delivery %]`, `[Avg Actual Delivery Days]`. Add slicers for `order_date` (Between), `customer_country`, `shipping_method`, and `carrier`. Set visual interactions so slicers filter all seven charts. Add optional tooltip `[Delivered Late %]` to avoid confusing the source's late flag with completed-delivery performance.

## 4. Layout

Canvas 16:9, white/light gray background. Header + four KPI cards; two rows of three visuals; bottom row contains scatter chart and slicers (see `dashboard_wireframe.md`). Use navy headings, teal for primary metrics, amber/red for late-delivery categories. Add source and definition note in footer.

## 5. Validate before publishing

1. Confirm `[Total Orders]` equals distinct `order_id` count (source has 50,000 rows; check duplicates).
2. Check donut category counts sum to total orders under the same filters.
3. Confirm monthly totals equal total orders when date slicer covers the full dataset.
4. Spot-check several carrier average costs and country totals using a temporary table visual.
5. Check map country recognition and scatter chart aggregation; inspect nulls and outliers.
6. Test each slicer and cross-filter interaction; save `.pbix` and capture `docs/dashboard.png`.

## 6. GitHub checklist

- [ ] `.pbix` built in Power BI Desktop and saved in `powerbi/`.
- [ ] Screenshot added to `docs/dashboard.png` and linked in README.
- [ ] Source dataset redistribution permitted.
- [ ] DAX measures validated, all seven visuals populated, slicers tested.
- [ ] Replace `YOUR_USERNAME` in the README GitHub URL.
- [ ] Commit and push project. If `.pbix` exceeds 100 MB, use Git LFS or a release/cloud link.
