# Data dictionary

The supplied workbook has **50,000 data rows** and **30 columns**.

| Field | Meaning / type |
|---|---|
| order_id | Order identifier; text |
| order_date | Order date; date |
| customer_id | Customer identifier; text |
| customer_segment | Customer type; text |
| customer_city | Customer city; text |
| customer_country | Customer country; text |
| warehouse_id | Warehouse identifier; text |
| warehouse_city | Warehouse city; text |
| product_category | Product category; text |
| product_weight_kg | Package/product weight; decimal kg |
| order_value_usd | Order value; USD decimal |
| shipping_method | Shipping service type; text |
| carrier | Shipping carrier; text |
| distance_km | Shipping distance; decimal km |
| promised_delivery_days | Promised delivery time; whole days |
| actual_delivery_days | Recorded actual delivery time; whole days |
| delivery_status | Delivery status; text |
| late_delivery | Source Yes/No late flag; text |
| delivery_delay_days | Recorded delivery delay; whole days |
| shipping_cost_usd | Shipping cost; USD decimal |
| package_size | Package size class; text |
| payment_method | Payment method; text |
| order_priority | Priority category; text |
| weather_condition | Weather condition; text |
| customer_rating | Customer rating; whole number |
| return_requested | Source Yes/No return request flag; text |
| return_reason | Return reason; text |
| delivery_attempts | Delivery attempts; whole number |
| warehouse_processing_hours | Warehouse processing time; decimal hours |
| tracking_status | Tracking status; text |

**Important:** `late_delivery` is a dataset flag and may appear for non-delivered orders. For completed-delivery punctuality use `delivery_status = "Delivered"` as a filter.
