# E-Commerce Delivery & Shipping Analytics | Power BI

A GitHub-ready Power BI portfolio project based on **50,000 e-commerce orders (2026)** and 30 fields. Analyze order volume, delivery punctuality, shipping costs, carrier performance, geography, and weather-related patterns.

> **Status:** Dashboard build kit. The seven charts, DAX measures, layout, theme, and source dataset are supplied. A native `.pbix` must be created in Power BI Desktop using the instructions below; no `.pbix` is included or claimed to have been generated.

## Dashboard preview / objectives

**KPI cards:** Total Orders · Total Revenue (USD) · Late Delivery % · Average Actual Delivery Days

| # | Visual | Axis / location | Values / legend |
|---|---|---|---|
| 1 | Clustered column | `shipping_method` | `Total Orders` |
| 2 | Donut | `late_delivery` | `Total Orders` |
| 3 | Line | `order_date` (Month, chronological) | `Total Orders` |
| 4 | Clustered bar | `carrier` | `Avg Shipping Cost (USD)` |
| 5 | 100% stacked column | `weather_condition` | `Total Orders`, legend `late_delivery` |
| 6 | Filled map or Azure Maps | `customer_country` (Country/Region) | `Total Orders` |
| 7 | Scatter | X `distance_km`; Y `actual_delivery_days` | Details `order_id`; tooltip `shipping_method`, `carrier` |

**Slicers:** `order_date`, `customer_country`, `shipping_method`, `carrier`.

## Files

- `data/ecommerce_delivery_shipping_2026.xlsx` — original uploaded dataset.
- `dax/measures.dax` — ready-to-copy DAX measures.
- `powerbi/theme.json` — dashboard color and typography theme.
- `docs/BUILD_GUIDE.md` — Power BI Desktop build instructions, chart settings, validation, and GitHub publishing.
- `docs/DATA_DICTIONARY.md` — dataset fields and types.
- `docs/dashboard_wireframe.md` — suggested one-page layout.
- `.gitignore` — ignore temporary files.

## Quick start

1. Open Power BI Desktop → **Get data → Excel workbook** → select `data/ecommerce_delivery_shipping_2026.xlsx`.
2. Select the data sheet and **Transform Data**; rename the query to `Shipping`.
3. Check data types: date for `order_date`; whole numbers for day/attempt fields; decimals for monetary and distance fields; text for categories and IDs.
4. **Close & Apply**. Create measures from `dax/measures.dax` using **Modeling → New measure** (one measure at a time).
5. Import `powerbi/theme.json` via **View → Themes → Browse for themes**.
6. Build the seven visuals and four KPI cards following `docs/BUILD_GUIDE.md`. Save as `powerbi/Ecommerce_Delivery_Analytics_2026.pbix`.
7. Take a dashboard screenshot and save to `docs/dashboard.png`, then update the screenshot link below before publishing.

<!-- After building, uncomment: ![Power BI dashboard](docs/dashboard.png) -->

## Interpretation notes

- `late_delivery` is the source dataset's Yes/No label; do not assume every row has completed delivery. Use the **Delivered Orders** and **Delivered Late %** measures when analyzing completed deliveries only.
- Weather, distance, and late deliveries can be associated without demonstrating causation.
- Dates and figures should be checked in Power BI after loading; no findings are asserted before chart validation.

## Publish to GitHub

```bash
git init
git add .
git commit -m "Add Power BI e-commerce delivery analytics project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ecommerce-delivery-powerbi.git
git push -u origin main
```

If the `.pbix` is too large for GitHub's regular file limit, use Git LFS or share it via a release/cloud link. The original dataset is included; review its redistribution rights before publishing.

## Tools

Power BI Desktop · Power Query · DAX · GitHub
